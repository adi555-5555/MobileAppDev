package com.example.searchCocktails;

public class Drink {

    String dName;
    String dAlc;
    String dThumb;
    String dIns;

    public Drink(String dName, String dAlc, String dThumb, String dIns) {
        this.dName = dName;
        this.dAlc = dAlc;
        this.dThumb = dThumb;
        this.dIns = dIns;
    }

    public String getdName() {
        return dName;
    }

    public void setdName(String dName) {
        this.dName = dName;
    }

    public String getdAlc() {
        return dAlc;
    }

    public void setdAlc(String dAlc) {
        this.dAlc = dAlc;
    }

    public String getdThumb() {
        return dThumb;
    }

    public void setdThumb(String dThumb) {
        this.dThumb = dThumb;
    }

    public String getdIns() {
        return dIns;
    }

    public void setdIns(String dIns) {
        this.dIns = dIns;
    }
}
