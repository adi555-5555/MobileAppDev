package com.example.searchCocktails;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedList;

public class SearchResultsActivity extends AppCompatActivity {

    String url = "https://www.thecocktaildb.com/api/json/v1/1/search.php?s=";
    private ProgressBar loadingPB;
    private RecyclerView mRecyclerView;
    private ItemListAdapter mAdapter;
    private final LinkedList<Drink> mItemList = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        url=url+message;

        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new ItemListAdapter(this, mItemList);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadingPB = findViewById(R.id.idLoadingPB);


        RequestQueue queue = Volley.newRequestQueue(SearchResultsActivity.this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url,
                null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                loadingPB.setVisibility(View.GONE);
                mRecyclerView.setVisibility(View.VISIBLE);

                try {
                    JSONArray jsonArray = new JSONArray(response.getString("drinks"));
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject item = jsonArray.getJSONObject(i);
                        String dName = item.getString("strDrink");
                        String dAlc = item.getString("strAlcoholic");
                        String dThumb = item.getString("strDrinkThumb");
                        String dIns = item.getString("strInstructions");

                        Drink m = new Drink(dName, dAlc, dThumb, dIns);
                        mItemList.add(m);
                        //System.out.println(dName);
                    }

                } catch (JSONException e) {
                    //Dialog dialog = new Dialog(context);
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("AppError", "Failed to get data.");
            }
        });
        queue.add(jsonObjectRequest);
    }
}