package com.example.searchCocktails;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.LinkedList;

public class ItemListAdapter extends RecyclerView.Adapter<ItemListAdapter.ItemViewHolder> {

    private LinkedList<Drink> mItemList;
    private LayoutInflater mInflater;

    public ItemListAdapter(Context context, LinkedList<Drink> itemList){
        mInflater = LayoutInflater.from(context);
        this.mItemList = itemList;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recy_item, parent, false);
        return new ItemViewHolder(itemView, this);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Drink mCurrent = mItemList.get(position);
        holder.titleTextView.setText(mCurrent.dName);
        holder.yearTextView.setText(mCurrent.dAlc);
        holder.dInsTextView.setText(mCurrent.dIns);
        Picasso.get().load(mCurrent.dThumb).into(holder.posterImageView);

    }

    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    class ItemViewHolder extends RecyclerView.ViewHolder {
        public final TextView titleTextView;
        public final TextView yearTextView;
        public final TextView dInsTextView;
        public final ImageView posterImageView;


        final ItemListAdapter mAdapter;

        public ItemViewHolder(View itemView, ItemListAdapter adapter) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            yearTextView = itemView.findViewById(R.id.yearTextView);
            dInsTextView = itemView.findViewById(R.id.dInsTextView);
            posterImageView = itemView.findViewById(R.id.posterImageView);
            this.mAdapter = adapter;

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    Toast.makeText(view.getContext(), mItemList.get(position).getdName(), Toast.LENGTH_SHORT).show();

                }
            });
        }
    }


}


